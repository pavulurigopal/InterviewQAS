###This playbook will create an IAM Policy

###Variables
```
iam_group - Name of the group the policy needs to be attached
iam_policy
```

###Note: Please edit the admin_policy.json currently it has AdministratorAccess
