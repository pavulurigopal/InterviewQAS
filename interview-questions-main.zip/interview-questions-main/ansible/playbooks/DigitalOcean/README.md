###Variables
```
#DigitalOcean
digitalocean_api_token :
droplet_size : 512mb
droplet_os : ubuntu-14-04-x64
droplet_region : sgp1

id_rsa :
id_rsa_pub :
ssh_key_name :
```
And `droplet_name` name is needed while creating a droplet
