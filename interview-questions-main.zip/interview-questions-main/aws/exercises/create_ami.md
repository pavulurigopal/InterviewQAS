## EC2 - Create an AMI

### Requirements

One running EC2 instance

### Objectives

1. Make some changes in the operating system of your instance (create files, modify files, ...)
2. Create an AMI image from running EC2 instance
3. Launch a new instance using the custom AMI you've created
