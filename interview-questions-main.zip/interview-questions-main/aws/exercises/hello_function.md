## Hello Function

Create a basic AWS Lambda function that when given a name, will return "Hello <NAME>"
