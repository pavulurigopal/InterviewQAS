
## Kuberenets cronjobs

- [cronjobs](https://medium.com/better-programming/tutorial-how-to-use-kubernetes-job-and-cronjob-1ef4ffbc8e84)
- [Cronjob 101](https://medium.com/jobteaser-dev-team/kubernetes-cronjob-101-56f0a8ea7ca2)
-[kube crons](https://medium.com/@ManagedKube/kubernetes-cron-jobs-9ec2ff36223a)
- [kube crons 02](https://medium.com/tensult/how-to-run-jobs-and-cronjobs-in-kubernetes-8661183a5b1a)
- [How To Create Kubernetes Jobs/Cron Jobs – Getting Started Guide](https://devopscube.com/create-kubernetes-jobs-cron-jobs/)
- [Sentry tutorial](https://medium.com/@gino.busok/azure-k8s-and-sentry-part-1-c70259508d50)
- [sentry helm](https://github.com/ginocbjr/sentry-helm)
- [Learning Kubernetes: persistent storage with Minikube](https://martincarstenbach.wordpress.com/2019/06/07/learning-kubernetes-persistent-storage-with-minikube/)
