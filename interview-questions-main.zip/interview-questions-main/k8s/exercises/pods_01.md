## Pods 01

#### Objective

Learn how to create pods

#### Instructions

1. Choose a container image (e.g. redis, nginx, mongo, etc.)
2. Create a pod (in the default namespace) using the image you chose
3. Verify the pod is running
